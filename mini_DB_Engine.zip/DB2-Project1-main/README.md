For notes/imp. info about the project, check the google docs folder.
